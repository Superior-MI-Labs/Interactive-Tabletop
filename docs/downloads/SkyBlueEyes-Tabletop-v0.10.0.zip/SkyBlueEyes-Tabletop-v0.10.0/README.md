# Phoenix Tabletop

**Free, local-first D&D character sheets and interactive tabletop dice.**

> **EARLY ALPHA / WORK IN PROGRESS.** This is a prototype, not a finished virtual tabletop or fully automated D&D rules engine. Expect incomplete imports, unsupported custom abilities, bugs, and changing save formats. Back up your characters regularly.

## Play in your browser

Launch the project's GitHub Pages site (once Pages is enabled) or open `docs/index.html` through a normal local HTTP server. **Start by uploading your D&D Beyond PDF character sheet.** The public website stores your character locally in your browser. No account or character-upload server is required.

* Import exported **D&D Beyond fillable character PDFs**, including multiclass and 2014/2024-era fields when present.
* Roll attacks, skills, saves, and dice using the tabletop's approximate 3D dice simulation.
* Track HP, equipment, conditions, resource charges, spells, available and prepared spells, custom actions, and notes.
* Export JSON frequently. Browser localStorage may be deleted by privacy tools or browser cleanup; importing on another device requires a JSON backup or the original PDF.
* The browser importer loads pinned Mozilla PDF.js code from jsDelivr when importing a PDF. **Your PDF bytes are processed locally in the tab**, not uploaded to the GitHub Pages server. An internet connection is needed to fetch the PDF parser unless it has been cached.

PDF parsing is designed for D&D Beyond's editable form exports; scanned images, password-protected PDFs, and arbitrary PDF layouts may not be supported. Importing a PDF is **not** a guarantee that every homebrew action or spell was exported or modeled correctly.

## Download / desktop mode

The ZIP under `docs/downloads/` includes the Python HTTP server and browser-based desktop launchers. Requires **Python 3.10+**, plus a supported browser (Chrome, Chromium or Edge). Optional Qt WebEngine integration is used if installed. It does *not* yet include native `.exe` or `.AppImage` builds. Windows launchers are provided but actual Windows testing is still required.

Linux Mint one-command installation after placing the downloaded desktop ZIP in `~/Downloads`:

```bash
unzip -p "$HOME/Downloads/SkyBlueEyes-Tabletop-v0.10.0.zip" SkyBlueEyes-Tabletop-v0.10.0/INSTALL.sh | bash
```

Or extract the archive and run `RUN-DESKTOP-LINUX.sh` or `RUN-DESKTOP-WINDOWS.bat`. The desktop build saves at `~/.skyblueeyes-tabletop/character.json` (user-home equivalent on Windows); Linux upgrades back it up. The desktop import uses the bundled Python pypdf library and does not depend on a PDF.js CDN.

## GitHub Pages publishing

Publish **`main` branch → `/docs` folder** from GitHub repository **Settings → Pages → Deploy from a branch**. No backend, secrets, API keys, or account database. The website is a generated copy of `web/`, with `window.__STATIC_TABLETOP__` enabled. Do not hand-edit `docs/` application sources; rebuild with `python3 tools/build_site.py`.

## Tested import samples (not included)

| Export | Class | HP | Attacks | Spells | Inventory entries |
|---|---|---:|---:|---:|---:|
| Sample A | Fighter 1 | 13 | 2 | 0 | 18 |
| Sample B | Bard 19 | 117 | 1 | 33 | 10 |
| Sample C | Monk 19 / Cleric 1 | 203 | 6 | 42 | 56 |

These are parser checks with sample PDFs supplied privately for QA. **None of those PDFs, exported field records, or saved character files are committed to this repo.** Counts only demonstrate field extraction, not full correctness of every custom rule. Synthetic PDF tests are included in source.

## Current limitations

- **Alpha status.** Some D&D Beyond custom actions appear only in its website, not in exported PDF form fields. Review and add missing homebrew manually.
- **Rules are not enforced** for every class, item, spell, feat or edition. Imported stats and bonuses are treated as supplied; do not automatically add modifiers twice.
- **Dice physics is approximate** and not a certified rigid-body/dice fairness engine.
- The public site depends on PDF.js CDN code for PDF uploads. Its PDF import path needs live-browser verification after Pages deployment; local normalization and desktop imports have been tested with supplied PDFs.
- For now there is one active character per browser origin or desktop installation. Export JSON before replacing one.
- If using a shared browser, locally stored character data may be accessible to other users of that browser profile.

## Tech / contribution

Python 3 server with vendored pypdf (desktop), vanilla JavaScript / CSS (UI), PDF.js (browser import) and localStorage (hosted saves). Character JSON is the single canonical state. Code MIT; bundled visual assets are original project assets. D&D Beyond is a third-party trademark; this project is unofficial and unaffiliated with Wizards of the Coast.

Issues and pull requests are welcome. Please do not attach other people's character PDFs or personal campaign notes to public GitHub issues.
